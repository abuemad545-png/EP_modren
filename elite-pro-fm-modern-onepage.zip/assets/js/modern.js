const topbar = document.querySelector("[data-topbar]");
const nav = document.querySelector("[data-nav]");
const navToggle = document.querySelector("[data-nav-toggle]");
const langToggle = document.querySelector("[data-lang-toggle]");

let translations = {
  en: {
    title: "Elite Pro FM | Modern One-Page Concept",
    nav: ["Proof", "Model", "Services", "Governance", "Industries", "Experience", "Partners", "Contact"],
    topCta: "RFQ",
    langButton: "عربي",
    eyebrow: "Rooted in Heritage. Driven by Excellence.",
    heroTitle: "Saudi Total Facilities Management, engineered for trust.",
    heroCopy: "Elite Pro FM combines SNASCO-backed governance, 30+ years of leadership depth, and COMO FMS international expertise to deliver measurable performance across complex assets.",
    heroPrimary: "Start an Inquiry",
    heroGhost: "Prequalification Readiness",
    panelSignal: "Operational Signal",
    panelModel: "Live Model",
    panelSmall: ["Years leadership", "COMO FMS years", "Helpdesk readiness", "Certified frameworks"],
    scroll: "Scroll",
    proofLabel: "Why Elite Pro FM",
    proofTitle: "Trust signals built into the operating model.",
    proofCopy: "Elite Pro FM is positioned for prequalification, tender participation, and enterprise partnerships by combining Saudi governance, SNASCO Holding support, and COMO FMS technical depth.",
    proofCards: [
      ["SNASCO", "Holding-backed governance", "Strategic direction, organizational support, and long-term enterprise credibility."],
      ["COMO FMS", "International FM expertise", "European-grade standards, certified systems, and more than 21 years of regional FM experience."],
      ["30+", "Leadership experience", "High-value FM, marine, industrial, security, hospitality, residential, and sensitive portfolios."],
      ["CAFM", "Measurable performance", "Work orders, dashboards, SLA tracking, KPI reporting, and lifecycle asset visibility."]
    ],
    modelLabel: "Delivery Model",
    modelTitle: "Local execution with international operating intelligence.",
    modelCopy: "Elite Pro FM leads Saudi delivery, client governance, mobilization, and contract accountability. COMO FMS strengthens the model with European-grade standards, certified systems, specialized technical expertise, and more than 21 years of regional FM experience.",
    modelCards: [
      ["Elite Pro FM", "Saudi market execution, client governance, service continuity, and SNASCO Holding support."],
      ["COMO FMS", "Technical methodology, compliance support, certified systems, and scalable TFM expertise."],
      ["Unified TFM", "Hard, soft, asset, helpdesk, CAFM, sustainability, and reporting under one disciplined structure."]
    ],
    servicesLabel: "Capabilities",
    servicesTitle: "One provider. Six connected service lines.",
    serviceCards: [
      ["Hard FM", "Core building systems", "Electrical, mechanical, HVAC, plumbing, civil, structural, planned preventive, corrective, and reactive maintenance."],
      ["Soft FM", "Experience and safety", "Cleaning, housekeeping, landscaping, waste management, pest control, and security operations with disciplined standards."],
      ["CAFM", "Data-led asset care", "Asset registers, work orders, helpdesk dispatch, MTBF analysis, forecasting, SLA dashboards, and lifecycle planning."],
      ["Energy", "Sustainable performance", "Consumption monitoring, HVAC optimization, responsible resource use, and gradual renewable-energy-ready practices."]
    ],
    deepServices: [
      ["Specialized Systems", "BMS, fire protection, life safety, CCTV, elevators, integrated control networks, and specialized mechanical systems."],
      ["Helpdesk & Support", "24/7 request intake, dispatching, work order traceability, response tracking, and documented closure."],
      ["Lifecycle Planning", "Asset condition checks, lifespan analysis, MTBF assessments, renewal forecasting, and lifecycle cost control."]
    ],
    governanceLabel: "Prequalification Ready",
    governanceTitle: "Built for tenders, audits, HSE reviews, and enterprise procurement.",
    governanceCopy: "Every engagement is structured around measurable performance, traceable delivery, safety discipline, and transparent reporting.",
    orbitCore: "CAFM<br>KPI<br>HSE",
    orbit: ["SLAs", "Audits", "Risk", "QA", "Reports", "Mobilization"],
    tenderCards: [
      ["Mobilization", "Transition plan, asset verification, staffing, risk register, and service readiness gates."],
      ["SLA / KPI Controls", "Response targets, completion standards, dashboards, escalation paths, and review rhythms."],
      ["HSE & Compliance", "Risk management, incident controls, emergency planning, audits, and compliance records."],
      ["Quality Assurance", "Inspections, corrective actions, reporting packs, and continuous improvement loops."]
    ],
    industriesLabel: "Industries Served",
    industriesTitle: "Built for diverse assets across the Kingdom.",
    industryCards: [
      ["Residential", "Compounds and private assets", "Preventive maintenance, occupant response, amenities, security coordination, and reliable daily operations."],
      ["Commercial", "Offices and business towers", "Tenant experience, technical uptime, common-area care, reporting, and escalation management."],
      ["Hospitality", "Guest-led service environments", "Housekeeping discipline, responsive maintenance, service refinement, and high-touch operational care."],
      ["Government", "Sensitive public environments", "Governance, compliance awareness, continuity planning, audits, and structured communication."],
      ["Mixed-use", "Complex destination assets", "Coordinated hard and soft services across residential, commercial, public, and shared infrastructure zones."],
      ["Industrial", "Technical and resilient operations", "HSE discipline, system reliability, planned maintenance, risk controls, and lifecycle planning."]
    ],
    experienceLabel: "Credibility",
    experienceTitle: "Experience translated into repeatable systems.",
    timeline: [
      ["Leadership Depth", "30+ years across high-value FM, marine, industrial, security, hospitality, residential, government, and private-sector portfolios."],
      ["Group Strength", "SNASCO Holding provides strategic direction, governance, and enterprise-building support."],
      ["Regional Proof", "COMO FMS brings experience across healthcare, finance, government, energy, industrial, education, and public-sector environments."]
    ],
    sectors: ["Residential", "Commercial", "Hospitality", "Government", "Mixed-use", "Industrial", "Education", "Public Sector"],
    partnersLabel: "Operating Ecosystem",
    partnersTitle: "Not only a provider. A controlled delivery network.",
    partnersCopy: "Elite Pro FM can structure qualified subcontractors, suppliers, manpower partners, and specialist service providers under governance, quality, HSE, and reporting expectations.",
    partnerCards: [
      ["Vendor Readiness", "Capability screening, compliance checks, scope alignment, and onboarding intent for qualified partners."],
      ["Service Governance", "Defined responsibilities, escalation routes, inspection cadence, and contract performance visibility."],
      ["Procurement Support", "RFQ response structure, tender documentation support, certification evidence, and scope clarification."],
      ["Continuous Improvement", "Audit feedback, corrective actions, reporting packs, and performance review cycles."]
    ],
    closingLabel: "Built for Saudi Assets",
    closingTitle: "Enterprise procurement deserves a facilities partner with evidence, structure, and operational discipline.",
    contactLabel: "Let’s Build the Tender Path",
    contactTitle: "Discuss RFQs, prequalification, or strategic FM partnerships.",
    contactCopy: "Use this concept as the bold one-page option. The forms are front-end ready and can connect later to WordPress, CRM, email routing, or secure tender upload.",
    formLabels: ["Inquiry Type", "Company", "Email", "Message"],
    options: ["RFQ", "Tender Submission", "Partnership", "General Inquiry"],
    placeholders: ["Company name", "name@company.com", "Scope, deadline, sector, or partnership details"],
    submit: "Send Inquiry",
    formStatus: "Prototype form ready for backend integration.",
    formThanks: "Thank you. This concept form is ready for CRM or WordPress integration."
  },
  ar: {
    title: "Elite Pro FM | مفهوم صفحة واحدة حديث",
    nav: ["الثقة", "النموذج", "الخدمات", "الحوكمة", "القطاعات", "الخبرة", "الشركاء", "تواصل"],
    topCta: "طلب عرض",
    langButton: "EN",
    eyebrow: "متجذرون في الإرث. مدفوعون بالتميز.",
    heroTitle: "إدارة مرافق سعودية شاملة، مصممة لبناء الثقة.",
    heroCopy: "تجمع Elite Pro FM بين حوكمة مدعومة من SNASCO، وخبرة قيادية تتجاوز 30 عاماً، وخبرة COMO FMS الدولية لتقديم أداء قابل للقياس في الأصول المعقدة.",
    heroPrimary: "ابدأ الاستفسار",
    heroGhost: "جاهزية التأهيل",
    panelSignal: "مؤشر التشغيل",
    panelModel: "النموذج التشغيلي",
    panelSmall: ["سنوات خبرة قيادية", "سنوات خبرة COMO FMS", "جاهزية مكتب الدعم", "أطر معتمدة"],
    scroll: "تمرير",
    proofLabel: "لماذا Elite Pro FM",
    proofTitle: "مؤشرات ثقة مدمجة داخل النموذج التشغيلي.",
    proofCopy: "تتموضع Elite Pro FM للتأهيل المسبق والمشاركة في المناقصات والشراكات المؤسسية من خلال حوكمة سعودية ودعم SNASCO Holding والخبرة الفنية لدى COMO FMS.",
    proofCards: [
      ["SNASCO", "حوكمة مدعومة من الشركة القابضة", "توجيه استراتيجي، دعم مؤسسي، ومصداقية طويلة الأمد."],
      ["COMO FMS", "خبرة دولية في إدارة المرافق", "معايير أوروبية، أنظمة معتمدة، وأكثر من 21 عاماً من الخبرة الإقليمية."],
      ["30+", "خبرة قيادية", "محافظ عالية القيمة في إدارة المرافق والقطاعات البحرية والصناعية والأمنية والضيافة والسكنية."],
      ["CAFM", "أداء قابل للقياس", "أوامر عمل، لوحات مؤشرات، متابعة SLA، تقارير KPI، ورؤية لدورة حياة الأصول."]
    ],
    modelLabel: "نموذج التسليم",
    modelTitle: "تنفيذ محلي مدعوم بذكاء تشغيلي دولي.",
    modelCopy: "تقود Elite Pro FM التنفيذ في السوق السعودي وحوكمة العميل والتعبئة ومساءلة العقود، بينما تعزز COMO FMS النموذج بمعايير أوروبية وأنظمة معتمدة وخبرة فنية متخصصة.",
    modelCards: [
      ["Elite Pro FM", "تنفيذ محلي، حوكمة العميل، استمرارية الخدمة، ودعم SNASCO Holding."],
      ["COMO FMS", "منهجيات فنية، دعم الامتثال، أنظمة معتمدة، وخبرة قابلة للتوسع في TFM."],
      ["نموذج TFM موحد", "خدمات صلبة وناعمة، أصول، مكتب دعم، CAFM، استدامة، وتقارير ضمن هيكل واحد منضبط."]
    ],
    servicesLabel: "القدرات",
    servicesTitle: "مزود واحد. خطوط خدمات مترابطة.",
    serviceCards: [
      ["الخدمات الصلبة", "أنظمة المباني الأساسية", "كهرباء، ميكانيكا، تكييف، سباكة، أعمال مدنية وإنشائية، وصيانة وقائية وتصحيحية وتفاعلية."],
      ["الخدمات الناعمة", "التجربة والسلامة", "نظافة، تدبير منزلي، تنسيق مواقع، إدارة نفايات، مكافحة آفات، وأمن بمعايير منضبطة."],
      ["CAFM", "إدارة أصول مبنية على البيانات", "سجلات أصول، أوامر عمل، مكتب دعم، تحليل MTBF، تنبؤات، لوحات SLA، وتخطيط دورة الحياة."],
      ["الطاقة", "أداء مستدام", "مراقبة الاستهلاك، تحسين التكييف، الاستخدام المسؤول للموارد، وممارسات جاهزة للطاقة المتجددة تدريجياً."]
    ],
    deepServices: [
      ["الأنظمة المتخصصة", "BMS، أنظمة الحريق وسلامة الحياة، CCTV، المصاعد، شبكات التحكم، والأنظمة الميكانيكية المتخصصة."],
      ["مكتب الدعم", "استقبال طلبات 24/7، dispatch، تتبع أوامر العمل، متابعة الاستجابة، وإغلاق موثق."],
      ["تخطيط دورة الحياة", "فحص حالة الأصول، تحليل العمر الافتراضي، تقييم MTBF، توقعات الاستبدال، وضبط تكاليف دورة الحياة."]
    ],
    governanceLabel: "جاهزية التأهيل المسبق",
    governanceTitle: "مصمم للمناقصات، التدقيق، مراجعات HSE، والمشتريات المؤسسية.",
    governanceCopy: "كل تعاقد مبني حول أداء قابل للقياس، تنفيذ قابل للتتبع، انضباط السلامة، وتقارير شفافة.",
    orbitCore: "CAFM<br>KPI<br>HSE",
    orbit: ["SLA", "تدقيق", "مخاطر", "جودة", "تقارير", "تعبئة"],
    tenderCards: [
      ["التعبئة", "خطة انتقال، التحقق من الأصول، التوظيف، سجل المخاطر، وبوابات جاهزية الخدمة."],
      ["ضوابط SLA / KPI", "أهداف الاستجابة، معايير الإنجاز، لوحات مؤشرات، مسارات تصعيد، وإيقاع مراجعة."],
      ["HSE والامتثال", "إدارة مخاطر، ضوابط حوادث، تخطيط طوارئ، تدقيق، وسجلات امتثال."],
      ["ضمان الجودة", "تفتيش، إجراءات تصحيحية، حزم تقارير، ودورات تحسين مستمر."]
    ],
    industriesLabel: "القطاعات المخدومة",
    industriesTitle: "جاهزون لأصول متنوعة في أنحاء المملكة.",
    industryCards: [
      ["سكني", "مجمعات وأصول خاصة", "صيانة وقائية، استجابة للسكان، مرافق، تنسيق أمني، وتشغيل يومي موثوق."],
      ["تجاري", "مكاتب وأبراج أعمال", "تجربة مستأجرين، جاهزية فنية، عناية بالمناطق المشتركة، تقارير، وإدارة تصعيد."],
      ["ضيافة", "بيئات خدمة متمحورة حول الضيف", "انضباط التدبير، صيانة سريعة، رقي في الخدمة، وعناية تشغيلية عالية."],
      ["حكومي", "بيئات عامة حساسة", "حوكمة، وعي بالامتثال، تخطيط استمرارية، تدقيق، وتواصل منظم."],
      ["متعدد الاستخدامات", "أصول وجهات معقدة", "تنسيق خدمات صلبة وناعمة عبر مناطق سكنية وتجارية وعامة وبنية مشتركة."],
      ["صناعي", "تشغيل فني ومرن", "انضباط HSE، موثوقية الأنظمة، صيانة مخططة، ضوابط مخاطر، وتخطيط دورة الحياة."]
    ],
    experienceLabel: "المصداقية",
    experienceTitle: "خبرة تتحول إلى أنظمة قابلة للتكرار.",
    timeline: [
      ["عمق قيادي", "أكثر من 30 عاماً في محافظ عالية القيمة تشمل إدارة المرافق والبحري والصناعي والأمني والضيافة والسكني والحكومي والخاص."],
      ["قوة المجموعة", "توفر SNASCO Holding التوجيه الاستراتيجي والحوكمة ودعم بناء الكيانات عالية الأداء."],
      ["إثبات إقليمي", "تقدم COMO FMS خبرة في قطاعات الصحة والتمويل والحكومة والطاقة والصناعة والتعليم والقطاع العام."]
    ],
    sectors: ["سكني", "تجاري", "ضيافة", "حكومي", "متعدد الاستخدامات", "صناعي", "تعليمي", "قطاع عام"],
    partnersLabel: "منظومة التشغيل",
    partnersTitle: "لسنا مجرد مزود خدمة. بل شبكة تسليم محكومة.",
    partnersCopy: "تستطيع Elite Pro FM تنظيم المقاولين الفرعيين والموردين وشركاء القوى العاملة ومقدمي الخدمات المتخصصة ضمن توقعات الحوكمة والجودة والسلامة والتقارير.",
    partnerCards: [
      ["جاهزية الموردين", "فحص القدرات، التحقق من الامتثال، مواءمة النطاق، ونية تأهيل الشركاء."],
      ["حوكمة الخدمة", "مسؤوليات محددة، مسارات تصعيد، إيقاع تفتيش، ورؤية لأداء العقد."],
      ["دعم المشتريات", "هيكلة ردود RFQ، دعم وثائق المناقصات، إثباتات الاعتماد، وتوضيح النطاق."],
      ["تحسين مستمر", "ملاحظات التدقيق، إجراءات تصحيحية، حزم تقارير، ودورات مراجعة أداء."]
    ],
    closingLabel: "مصمم لأصول المملكة",
    closingTitle: "المشتريات المؤسسية تحتاج شريك مرافق يملك الدليل والهيكل والانضباط التشغيلي.",
    contactLabel: "لنبدأ مسار المناقصة",
    contactTitle: "ناقش طلبات الأسعار، التأهيل المسبق، أو الشراكات الاستراتيجية.",
    contactCopy: "هذا النموذج جاهز كخيار صفحة واحدة قوية، ويمكن ربط النماذج لاحقاً مع WordPress أو CRM أو البريد أو رفع ملفات آمن للمناقصات.",
    formLabels: ["نوع الاستفسار", "الشركة", "البريد الإلكتروني", "الرسالة"],
    options: ["طلب عرض سعر", "مناقصة", "شراكة", "استفسار عام"],
    placeholders: ["اسم الشركة", "name@company.com", "النطاق، الموعد النهائي، القطاع، أو تفاصيل الشراكة"],
    submit: "إرسال الاستفسار",
    formStatus: "نموذج أولي جاهز للربط الخلفي.",
    formThanks: "شكراً لك. هذا النموذج جاهز للربط مع CRM أو WordPress."
  }
};

let activeLang = localStorage.getItem("eliteModernLang") || "en";

const setText = (selector, text, root = document) => {
  const el = root.querySelector(selector);
  if (el) el.textContent = text;
};

const setHtml = (selector, html, root = document) => {
  const el = root.querySelector(selector);
  if (el) el.innerHTML = html;
};

const applyLanguage = (lang) => {
  const t = translations[lang];
  activeLang = lang;
  localStorage.setItem("eliteModernLang", lang);
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.title = t.title;
  langToggle.textContent = t.langButton;

  nav.querySelectorAll("a").forEach((link, index) => {
    link.textContent = t.nav[index];
  });
  setText(".top-cta", t.topCta);
  setText(".eyebrow", t.eyebrow);
  setText(".hero h1", t.heroTitle);
  setText(".hero-copy", t.heroCopy);
  setText(".hero-actions .primary", t.heroPrimary);
  setText(".hero-actions .ghost", t.heroGhost);
  setText(".panel-head span", t.panelSignal);
  setText(".panel-head strong", t.panelModel);
  document.querySelectorAll(".panel-grid small").forEach((el, index) => {
    el.textContent = t.panelSmall[index];
  });
  setText(".scroll-cue", t.scroll);

  setText(".proof-intro span", t.proofLabel);
  setText(".proof-intro h2", t.proofTitle);
  setText(".proof-intro p", t.proofCopy);
  document.querySelectorAll(".proof-card").forEach((card, index) => {
    const item = t.proofCards[index];
    setText("b", item[0], card);
    setText("h3", item[1], card);
    setText("p", item[2], card);
  });

  setText(".section-label", t.modelLabel);
  setText(".intro-copy h2", t.modelTitle);
  setText(".intro-copy p", t.modelCopy);
  document.querySelectorAll(".model-stack article").forEach((card, index) => {
    const item = t.modelCards[index];
    setText("h3", item[0], card);
    setText("p", item[1], card);
  });

  setText("#services .section-title span", t.servicesLabel);
  setText("#services .section-title h2", t.servicesTitle);
  document.querySelectorAll(".service").forEach((card, index) => {
    const item = t.serviceCards[index];
    setText("span", item[0], card);
    setText("h3", item[1], card);
    setText("p", item[2], card);
  });
  document.querySelectorAll(".service-deep-grid article").forEach((card, index) => {
    const item = t.deepServices[index];
    setText("strong", item[0], card);
    setText("p", item[1], card);
  });

  setText(".governance-copy span", t.governanceLabel);
  setText(".governance-copy h2", t.governanceTitle);
  setText(".governance-copy p", t.governanceCopy);
  setHtml(".orbit-core", t.orbitCore);
  document.querySelectorAll(".orbit > span").forEach((el, index) => {
    el.textContent = t.orbit[index];
  });
  document.querySelectorAll(".tender-framework article").forEach((card, index) => {
    const item = t.tenderCards[index];
    setText("h3", item[0], card);
    setText("p", item[1], card);
  });

  setText("#industries .section-title span", t.industriesLabel);
  setText("#industries .section-title h2", t.industriesTitle);
  document.querySelectorAll(".industry-grid article").forEach((card, index) => {
    const item = t.industryCards[index];
    setText("span", item[0], card);
    setText("h3", item[1], card);
    setText("p", item[2], card);
  });

  setText("#experience .section-title span", t.experienceLabel);
  setText("#experience .section-title h2", t.experienceTitle);
  document.querySelectorAll(".timeline article").forEach((card, index) => {
    const item = t.timeline[index];
    setText("h3", item[0], card);
    setText("p", item[1], card);
  });
  document.querySelectorAll(".sector-marquee span").forEach((el, index) => {
    el.textContent = t.sectors[index];
  });

  setText(".operating-copy span", t.partnersLabel);
  setText(".operating-copy h2", t.partnersTitle);
  setText(".operating-copy p", t.partnersCopy);
  document.querySelectorAll(".operating-grid article").forEach((card, index) => {
    const item = t.partnerCards[index];
    setText("h3", item[0], card);
    setText("p", item[1], card);
  });

  setText(".closing-statement span", t.closingLabel);
  setText(".closing-statement h2", t.closingTitle);
  setText(".contact-card > div span", t.contactLabel);
  setText(".contact-card > div h2", t.contactTitle);
  setText(".contact-card > div p", t.contactCopy);
  document.querySelectorAll("[data-modern-form] label").forEach((label, index) => {
    label.childNodes[0].nodeValue = `${t.formLabels[index]} `;
  });
  document.querySelectorAll("[data-modern-form] option").forEach((option, index) => {
    option.textContent = t.options[index];
  });
  const form = document.querySelector("[data-modern-form]");
  form.querySelector('input[type="text"]').placeholder = t.placeholders[0];
  form.querySelector('input[type="email"]').placeholder = t.placeholders[1];
  form.querySelector("textarea").placeholder = t.placeholders[2];
  setText('[data-modern-form] button[type="submit"]', t.submit);
  setText("[data-form-status]", t.formStatus);
};

langToggle?.addEventListener("click", () => {
  applyLanguage(activeLang === "en" ? "ar" : "en");
  window.setTimeout(revealVisibleItems, 80);
});

const loadTranslations = async () => {
  try {
    const response = await fetch("assets/i18n/modern-translations.json", { cache: "no-store" });
    if (response.ok) {
      translations = await response.json();
    }
  } catch (error) {
    console.warn("Using built-in translations because the external translation file could not be loaded.", error);
  }
  applyLanguage(activeLang);
};

loadTranslations();

window.addEventListener("scroll", () => {
  topbar?.classList.toggle("scrolled", window.scrollY > 24);
});

navToggle?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", String(open));
});

nav?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", (event) => {
    const href = link.getAttribute("href");
    if (href?.startsWith("#")) {
      const target = document.querySelector(href);
      if (target) {
        event.preventDefault();
        const offset = topbar ? topbar.offsetHeight + 24 : 96;
        const y = target.getBoundingClientRect().top + window.scrollY - offset;
        window.history.pushState(null, "", href);
        window.scrollTo({ top: y, behavior: "smooth" });
        window.setTimeout(revealVisibleItems, 220);
      }
    }
    nav.classList.remove("open");
    navToggle?.setAttribute("aria-expanded", "false");
  });
});

const reveals = document.querySelectorAll(".reveal");
const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("in");
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.16 }
);

reveals.forEach((item) => revealObserver.observe(item));

const revealVisibleItems = () => {
  reveals.forEach((item) => {
    const rect = item.getBoundingClientRect();
    if (rect.top < window.innerHeight * 1.15 && rect.bottom > -80) {
      item.classList.add("in");
    }
  });
};

window.addEventListener("load", revealVisibleItems);
const scrollToCurrentHash = () => {
  if (!window.location.hash) return;
  const target = document.querySelector(window.location.hash);
  if (!target) return;
  const offset = topbar ? topbar.offsetHeight + 24 : 96;
  window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY - offset });
};

window.addEventListener("load", () => {
  window.setTimeout(scrollToCurrentHash, 80);
  window.setTimeout(revealVisibleItems, 160);
});
window.addEventListener("hashchange", () => {
  window.setTimeout(scrollToCurrentHash, 20);
  window.setTimeout(revealVisibleItems, 120);
});
window.setTimeout(revealVisibleItems, 120);
window.setTimeout(revealVisibleItems, 700);

const counters = document.querySelectorAll("[data-count]");
const counterObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = Number(el.dataset.count);
      let current = 0;
      const step = Math.max(1, Math.ceil(target / 34));
      const tick = () => {
        current = Math.min(target, current + step);
        el.textContent = `${current}+`;
        if (current < target) requestAnimationFrame(tick);
      };
      tick();
      counterObserver.unobserve(el);
    });
  },
  { threshold: 0.6 }
);

counters.forEach((counter) => counterObserver.observe(counter));

document.querySelector("[data-modern-form]")?.addEventListener("submit", (event) => {
  event.preventDefault();
  const status = document.querySelector("[data-form-status]");
  if (status) status.textContent = translations[activeLang].formThanks;
  event.currentTarget.reset();
});
